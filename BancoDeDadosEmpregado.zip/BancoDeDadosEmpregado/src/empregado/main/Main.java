package empregado.main;

import empregado.conexao.Conexao;
import empregado.menu.Menu;

public class Main {
	public static void main(String[] args) {
		
		new Menu().menu();
//		System.out.println(new Conexao().conectar());

	}
}
